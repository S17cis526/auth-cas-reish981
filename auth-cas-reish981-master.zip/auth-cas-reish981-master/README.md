# auth-cas
An implementation of a CAS client using express
